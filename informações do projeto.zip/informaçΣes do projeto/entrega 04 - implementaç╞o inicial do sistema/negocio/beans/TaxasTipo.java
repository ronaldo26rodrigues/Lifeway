package negocio.beans;

public enum TaxasTipo {
    ;

    public Object getTipo() {
        return null;
    }

}

package negocio.beans;

public class TaxasporTipo {

    public TaxasporTipo(TipoPropriedade tipo) {
    }

}

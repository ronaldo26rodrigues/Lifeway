package negocio.beans;

public enum TipoEmpresa {
    
    ENERGIA,
    ÁGUA
    
}

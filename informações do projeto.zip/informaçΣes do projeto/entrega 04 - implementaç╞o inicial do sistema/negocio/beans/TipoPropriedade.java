package negocio.beans;

public enum TipoPropriedade {
    
    RESIDENCIAL,
    COMERCIAL,
    INDUSTRIAL,
    PUBLICA
    
}
